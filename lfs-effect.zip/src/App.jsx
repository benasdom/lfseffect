import { HashRouter, Routes, Route } from 'react-router-dom'
import { ThemeProvider } from './context/ThemeContext'
import AppShell from './layouts/AppShell'
import Home from './pages/Home'
import Styles from './pages/Styles'
import Gallery from './pages/Gallery'
import Shop from './pages/Shop'
import Profile from './pages/Profile'

export default function App() {
  return (
    <ThemeProvider>
      <HashRouter>
        <Routes>
          <Route element={<AppShell />}>
            <Route path="/" element={<Home />} />
            <Route path="/styles" element={<Styles />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/profile" element={<Profile />} />
          </Route>
        </Routes>
      </HashRouter>
    </ThemeProvider>
  )
}
