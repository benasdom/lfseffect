# lfs Effect — PWA

A React + Vite + Tailwind CSS v4 progressive web app for a sculptural braiding studio, installable as a standalone app on both iOS and Android. Built to match the supplied screenshot exactly, with a light and dark theme.

## Run it

```bash
npm install
npm run dev
```

Open the printed local URL on your phone (same Wi-Fi) or in a desktop browser resized to a phone width — the layout is mobile-first and centers itself in a max-width frame on larger screens.

## Build for production

```bash
npm run build
npm run preview
```

`npm run build` outputs a `dist/` folder with a generated `manifest.webmanifest` and service worker (via `vite-plugin-pwa`), so it can be installed to the home screen on iOS Safari ("Add to Home Screen") and Android Chrome ("Install app") and runs `display: standalone` (no browser chrome).

## Structure

- `src/components/icons/` — every icon is a hand-drawn, animated SVG (via `framer-motion`): the comb for Styles, the framed photo for Gallery, the calendar+clock for Book, the bag for Shop, the person for Profile, plus the sun/moon theme toggle, hamburger-to-X menu, WhatsApp bubble and the logo mark.
- `src/components/BottomNav.jsx` — the signature piece: the active tab isolates into a raised, brass-ringed bubble that glides between positions with a spring animation, exactly like the reference screenshot's floating "Book" button.
- `src/components/PlaceholderPortrait.jsx` — a gradient + line-art stand-in for the real salon photography. Swap it for a real `<img>` wherever it's used (`Hero.jsx`, `Styles.jsx`, `Gallery.jsx`, `Shop.jsx`) — it's a one-line change per spot.
- `src/context/ThemeContext.jsx` — light/dark mode, persisted to `localStorage`, defaults to the device's OS preference.
- `src/pages/` — Home ("let's tour."), Styles, Gallery, Shop, Profile — one per bottom-nav tab.

## Design tokens

Defined in `src/index.css` under `@theme`: a warm ivory/near-black pairing lifted from the salon's gold mirror frames and marble floors, with a muted brass accent (`--color-brass`) used sparingly for rings, dividers and price tags. Display type is Fraunces (italic for editorial moments like "tour."); UI text is Inter.
